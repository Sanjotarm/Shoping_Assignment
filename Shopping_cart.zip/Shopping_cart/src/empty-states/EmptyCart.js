import React, { Component } from "react";

const EmptyCart = props => {
  return (
    <div className="empty-cart">
      <h1>You cart is empty!</h1>
    </div>
  );
};

export default EmptyCart;
